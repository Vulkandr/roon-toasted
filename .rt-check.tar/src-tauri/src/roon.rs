// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at https://mozilla.org/MPL/2.0/.

//! Roon connection.
//!
//! Finds Roon Cores on the network, connects to exactly one of them, and keeps
//! a live status (connected Core + every Core on the network) that the UI can
//! read with the `roon_status` command or follow with the `roon-status` event.
//! Zones and playback live in zones.rs, which this hands each connection to.

use std::collections::{HashMap, HashSet};
use std::net::Ipv4Addr;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, Instant};

use roon_api::{ApiError, FileStateStore, RoonClient, RoonClientBuilder, RoonEvent, StateStore};
use serde::Serialize;
use tauri::{AppHandle, Emitter, Manager, State};
use tokio::sync::broadcast::error::RecvError;
use tokio::task::JoinHandle;

/// A Core seen on the network. Cores that stop answering for this long drop off the list.
const CORE_EXPIRY: Duration = Duration::from_secs(150);

// ---------------------------------------------------------------------------
// Status shared with the UI
// ---------------------------------------------------------------------------

/// One Roon Core, as shown in Settings.
#[derive(Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct CoreInfo {
    pub core_id: String,
    pub name: String,
    pub host: String,
    pub port: u16,
}

#[derive(Clone, Copy, Serialize, PartialEq, Debug)]
#[serde(rename_all = "lowercase")]
pub enum ConnectionState {
    /// Looking for the Core (or waiting for it to be enabled in Roon).
    Searching,
    Connected,
    /// Was connected, lost it, retrying automatically.
    Reconnecting,
}

/// What `roon_status` returns and the `roon-status` event carries.
#[derive(Clone, Serialize, PartialEq)]
#[serde(rename_all = "camelCase")]
pub struct RoonStatus {
    pub state: ConnectionState,
    /// The Core this app is set to use (remembered from the last pairing), even
    /// before it's been found on the network. None until the first pairing.
    pub paired_core_id: Option<String>,
    /// The Core this app is paired with (filled in once it's been seen).
    pub connected: Option<CoreInfo>,
    /// Every Core currently answering on the network, including the connected one.
    pub available: Vec<CoreInfo>,
}

struct Inner {
    state: ConnectionState,
    paired_core_id: Option<String>,
    connected: Option<CoreInfo>,
    seen: HashMap<String, (CoreInfo, Instant)>,
    last_sent: Option<RoonStatus>,
}

/// Handle to the Roon status, stored in Tauri's managed state.
///
/// It's registered with the app before any window exists (so a page asking
/// for the status at startup always gets an answer), and `start()` fills in
/// the app handle and pairing file path a moment later.
pub struct Roon {
    inner: Mutex<Inner>,
    state_path: OnceLock<PathBuf>,
    app: OnceLock<AppHandle>,
    /// Steers discovery (search again, direct queries); set once discovery is up.
    control: Mutex<Option<roon_sood::SoodControl>>,
    /// Tells the connection loop the manual address changed.
    manual_changed: Mutex<Option<tokio::sync::mpsc::UnboundedSender<()>>>,
    /// What the direct (typed address) connection is doing, for the Manual panel.
    direct: Mutex<DirectState>,
}

/// The direct connection to a typed-in address, for the Manual panel.
#[derive(Clone, Serialize, PartialEq, Default)]
#[serde(rename_all = "lowercase")]
pub enum DirectState {
    /// Not trying (no manual address, the Core answered the search, or connected).
    #[default]
    Idle,
    /// The address didn't answer the search; connecting to host:port directly.
    Connecting,
    /// Connected through the typed address.
    Connected,
    /// The last direct attempt failed; retrying.
    Failed,
}

impl Default for Roon {
    fn default() -> Self {
        Self {
            inner: Mutex::new(Inner {
                state: ConnectionState::Searching,
                paired_core_id: None,
                connected: None,
                seen: HashMap::new(),
                last_sent: None,
            }),
            state_path: OnceLock::new(),
            app: OnceLock::new(),
            control: Mutex::new(None),
            manual_changed: Mutex::new(None),
            direct: Mutex::new(DirectState::Idle),
        }
    }
}

impl Roon {
    fn snapshot(inner: &Inner) -> RoonStatus {
        let mut available: Vec<CoreInfo> = inner.seen.values().map(|(c, _)| c.clone()).collect();
        available.sort_by_key(|c| c.name.to_lowercase());
        RoonStatus {
            state: inner.state,
            paired_core_id: inner.paired_core_id.clone(),
            connected: inner.connected.clone(),
            available,
        }
    }

    pub fn status(&self) -> RoonStatus {
        Self::snapshot(&self.inner.lock().unwrap())
    }

    /// Applies a change, then tells the UI (and the dev terminal) if anything actually changed.
    fn update(&self, change: impl FnOnce(&mut Inner)) {
        let (status, pairing_changed) = {
            let mut inner = self.inner.lock().unwrap();
            let was_paired = inner.paired_core_id.is_some();
            change(&mut inner);
            let pairing_changed = was_paired != inner.paired_core_id.is_some();
            let status = Self::snapshot(&inner);
            if inner.last_sent.as_ref() == Some(&status) {
                return;
            }
            inner.last_sent = Some(status.clone());
            (status, pairing_changed)
        };
        print_status(&status);
        if let Some(app) = self.app.get() {
            let _ = app.emit("roon-status", &status);
            // Auto-Hide only acts once a Core is paired (see settings.rs)
            if pairing_changed {
                crate::settings::apply_taskbar(app);
            }
            // The library connection follows the Core (see library.rs)
            crate::library::reconsider(app);
        }
    }

    fn core_seen(&self, core: CoreInfo) {
        self.update(|inner| {
            if inner.connected.as_ref().is_some_and(|c| c.core_id == core.core_id) {
                inner.connected = Some(core.clone());
            }
            inner.seen.insert(core.core_id.clone(), (core, Instant::now()));
        });
    }

    fn set_direct(&self, state: DirectState) {
        let changed = {
            let mut direct = self.direct.lock().unwrap();
            let changed = *direct != state;
            *direct = state;
            changed
        };
        if changed {
            if let Some(app) = self.app.get() {
                let _ = app.emit("roon-status", &self.status());
            }
        }
    }

    fn remove_stale_cores(&self) {
        self.update(|inner| inner.seen.retain(|_, (_, last)| last.elapsed() < CORE_EXPIRY));
    }
}

fn print_status(status: &RoonStatus) {
    let current = match &status.connected {
        Some(c) => format!("{:?}, {} at {}", status.state, c.name, c.host),
        None => format!("{:?}", status.state),
    };
    let others: Vec<&str> = status
        .available
        .iter()
        .filter(|c| status.paired_core_id.as_ref() != Some(&c.core_id))
        .map(|c| c.name.as_str())
        .collect();
    if others.is_empty() {
        println!("[roon] status: {current}");
    } else {
        println!("[roon] status: {current} | other Cores: {}", others.join(", "));
    }
}

// ---------------------------------------------------------------------------
// Commands the UI can call
// ---------------------------------------------------------------------------

/// Current connection status and Core list.
#[tauri::command]
pub fn roon_status(roon: State<'_, Roon>) -> RoonStatus {
    roon.status()
}

/// Makes a different Core the paired one, then restarts the app to connect to it.
///
/// roon-api's reconnect loop can't be stopped once it starts, so a quick restart
/// is the clean way to let go of the old Core. This is an async command on
/// purpose: restarting from a background thread lets Tauri shut down fully first
/// (releasing the single-instance lock) before the new copy starts.
#[tauri::command]
pub async fn switch_core(roon: State<'_, Roon>, core_id: String) -> Result<(), String> {
    let status = roon.status();
    if status.connected.as_ref().is_some_and(|c| c.core_id == core_id) {
        return Ok(()); // Already using it.
    }
    let Some(core) = status.available.iter().find(|c| c.core_id == core_id) else {
        return Err("That Core isn't on the network right now.".into());
    };

    let (Some(state_path), Some(app)) = (roon.state_path.get(), roon.app.get()) else {
        return Err("Still starting up, try again in a moment.".into());
    };
    FileStateStore::new(state_path.clone())
        .save_paired_core_id(Some(&core_id))
        .map_err(|e| format!("Couldn't save the new Core: {e}"))?;
    println!("[roon] switching to \"{}\", restarting...", core.name);
    // The new copy waits for this one's WebView2 to close (see lib.rs)
    std::env::set_var(crate::RESTARTED_ENV, "1");
    app.restart();
}


/// Searches the network for Cores again right now.
#[tauri::command]
pub fn roon_search_again(roon: State<'_, Roon>) -> Result<(), String> {
    match roon.control.lock().unwrap().as_ref() {
        Some(control) => {
            println!("[roon] searching again (asked from Settings)");
            control.search_now();
            Ok(())
        }
        None => Err("Still starting up, try again in a moment.".into()),
    }
}

/// Saves (or clears, with None or an empty string) a Core address typed in by
/// hand, and searches again with it. The address is asked directly on every
/// search, so it works even when multicast and broadcast don't reach the Core.
#[tauri::command]
pub fn roon_set_manual_core(
    app: AppHandle,
    roon: State<'_, Roon>,
    address: Option<String>,
    port: Option<u16>,
) -> Result<(), String> {
    let address = address.map(|a| a.trim().to_string()).filter(|a| !a.is_empty());
    let host = match &address {
        Some(text) => {
            let ip: Ipv4Addr = text.parse().map_err(|_| {
                "Enter the Core's IPv4 address, like 192.168.1.20 (no port needed).".to_string()
            })?;
            if ip.is_loopback() || ip.is_unspecified() || ip.is_broadcast() || ip.is_multicast() {
                return Err("That isn't an address a Core can be reached at.".to_string());
            }
            Some(ip.to_string())
        }
        None => None,
    };

    let path = crate::settings::path(&app).ok_or("Couldn't find the app data folder.")?;
    let port = port.unwrap_or(crate::settings::DEFAULT_CORE_PORT);
    if port == 0 {
        return Err("The port must be between 1 and 65535.".into());
    }
    let mut settings = crate::settings::load(&path);
    settings.manual_core_host = host.clone();
    settings.manual_core_port = port;
    crate::settings::save(&path, &settings)?;
    match &host {
        Some(h) => println!("[roon] manual Core address set to {h}:{port}"),
        None => println!("[roon] manual Core address cleared"),
    }

    if let Some(control) = roon.control.lock().unwrap().as_ref() {
        control.set_known_hosts(known_hosts(&settings));
    }
    if let Some(tx) = roon.manual_changed.lock().unwrap().as_ref() {
        let _ = tx.send(());
    }
    Ok(())
}

/// Addresses asked directly on every search: the one typed in by hand and
/// where the paired Core was last seen.
fn known_hosts(settings: &crate::settings::AppSettings) -> Vec<Ipv4Addr> {
    let mut hosts: Vec<Ipv4Addr> = Vec::new();
    for text in [&settings.manual_core_host, &settings.last_core_host]
        .into_iter()
        .flatten()
    {
        if let Ok(ip) = text.parse::<Ipv4Addr>() {
            if !hosts.contains(&ip) {
                hosts.push(ip);
            }
        }
    }
    hosts
}

/// One network adapter the search goes out of, with what came back.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterInfo {
    pub ip: String,
    pub queries_sent: u64,
    pub replies: u64,
}

/// What the Diagnostics dropdown in Settings shows.
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Diagnostics {
    pub app_version: String,
    pub adapters: Vec<AdapterInfo>,
    /// Answers that came in on the shared sockets rather than one adapter's.
    pub other_replies: u64,
    pub searches: u64,
    pub last_search_secs_ago: Option<u64>,
    pub last_reply_secs_ago: Option<u64>,
    pub last_reply_from: Option<String>,
    /// Addresses asked directly on every search.
    pub known_hosts: Vec<String>,
    /// The address typed in under Manual, if any, and its port.
    pub manual_core: Option<String>,
    pub manual_port: u16,
    /// Whether a Core has answered the search at that address.
    pub manual_answered: bool,
    /// What the direct connection to the typed address is doing.
    pub direct: DirectState,
}

#[tauri::command]
pub fn roon_diagnostics(app: AppHandle, roon: State<'_, Roon>) -> Result<Diagnostics, String> {
    let Some(control) = roon.control.lock().unwrap().clone() else {
        return Err("Still starting up, try again in a moment.".into());
    };
    let diag = control.diagnostics();
    let settings = crate::settings::path(&app)
        .map(|p| crate::settings::load(&p))
        .unwrap_or_default();
    let status = roon.status();

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    let ago = |t: Option<u64>| t.map(|t| now.saturating_sub(t));

    let manual_answered = settings
        .manual_core_host
        .as_ref()
        .is_some_and(|m| status.available.iter().any(|c| &c.host == m));

    Ok(Diagnostics {
        app_version: app.package_info().version.to_string(),
        adapters: diag
            .adapters
            .iter()
            .map(|a| AdapterInfo {
                ip: a.ip.to_string(),
                queries_sent: a.queries_sent,
                replies: a.replies,
            })
            .collect(),
        other_replies: diag.other_replies,
        searches: diag.searches,
        last_search_secs_ago: ago(diag.last_search_unix),
        last_reply_secs_ago: ago(diag.last_reply_unix),
        last_reply_from: diag.last_reply_from.map(|ip| ip.to_string()),
        known_hosts: diag.known_hosts.iter().map(|h| h.to_string()).collect(),
        manual_core: settings.manual_core_host,
        manual_port: settings.manual_core_port,
        manual_answered,
        direct: roon.direct.lock().unwrap().clone(),
    })
}

// ---------------------------------------------------------------------------
// Connection
// ---------------------------------------------------------------------------

/// Connects the Roon status to the app and starts connecting in the background.
/// Returns immediately. (`Roon` itself is registered in lib.rs before any window opens.)
pub fn start(app: &AppHandle) {
    // Pairing approval is saved here so Roon only asks once:
    // %APPDATA%\com.vulkan.roon-toasted\roon-state.json on Windows.
    let state_path = match app.path().app_data_dir() {
        Ok(dir) => dir.join("roon-state.json"),
        Err(e) => {
            eprintln!("[roon] couldn't find the app data folder: {e}");
            return;
        }
    };
    let roon = app.state::<Roon>();
    let _ = roon.state_path.set(state_path.clone());
    let _ = roon.app.set(app.clone());

    let app = app.clone();
    tauri::async_runtime::spawn(async move {
        if let Err(e) = run(app, state_path).await {
            eprintln!("[roon] connection stopped: {e}");
        }
    });
}

async fn run(app: AppHandle, state_path: PathBuf) -> Result<(), ApiError> {
    if let Some(dir) = state_path.parent() {
        let _ = std::fs::create_dir_all(dir);
    }
    println!("[roon] pairing file: {}", state_path.display());

    // How the app introduces itself in Roon > Settings > Extensions.
    let version = app.package_info().version.to_string();
    let client = RoonClientBuilder::new(
        "com.vulkan.roon-toasted",
        "Roon: Toasted",
        &version,
        "Vulkandr",
        "",
    )
    .website("https://github.com/Vulkandr")
    .token_store(FileStateStore::new(state_path))
    .require_transport()
    .require_browse()
    .build()?;
    let client = Arc::new(client);

    // Connection events keep arriving for the life of the app (including
    // automatic reconnects), so they get their own listener.
    let mut events = client.events();
    let events_app = app.clone();
    tauri::async_runtime::spawn(async move {
        let roon = events_app.state::<Roon>();
        loop {
            match events.recv().await {
                Ok(RoonEvent::CorePaired(core)) => {
                    println!(
                        "[roon] connected to \"{}\" (Roon {})",
                        core.display_name(),
                        core.display_version()
                    );
                    let core_id = core.core_id().to_string();
                    let fallback_name = core.display_name().to_string();
                    roon.update(|inner| {
                        inner.state = ConnectionState::Connected;
                        inner.paired_core_id = Some(core_id.clone());
                        inner.connected = Some(match inner.seen.get(&core_id) {
                            Some((info, _)) => info.clone(),
                            None => CoreInfo {
                                core_id,
                                name: fallback_name,
                                host: String::new(),
                                port: 0,
                            },
                        });
                    });
                    // Each (re)connection gets its own zone watcher; the old one ends with its connection.
                    crate::zones::attach(&events_app, core);
                }
                Ok(RoonEvent::CoreLost { .. }) => {
                    roon.update(|inner| inner.state = ConnectionState::Reconnecting);
                    crate::zones::detach(&events_app);
                }
                Ok(_) => {}
                // Fell behind on events; skip ahead rather than stop.
                Err(RecvError::Lagged(_)) => continue,
                Err(RecvError::Closed) => break,
            }
        }
    });

    discover_and_connect(&app, &client).await
}

/// Keeps listening for Cores on the network for the life of the app (so the
/// "available" list stays current) and connects to exactly one of them.
///
/// Networks can have more than one Core answering (an old or idle install,
/// for example), so the app decides which one to use instead of retrying
/// every Core it hears from:
/// - Already paired: only that Core is used. Others are listed but left alone.
/// - Not paired yet: every Core found is tried at once, and whichever one the
///   user enables "Roon: Toasted" on first becomes the paired Core.
///
/// Once connected, roon-api's own reconnect (with backoff) keeps that one
/// connection alive, and discovery keeps the list up to date. If the Core
/// turns up at a new address (it got a new IP), the reconnect is pointed there
/// (`set_core_address`, added in our copy of roon-api).
async fn discover_and_connect(app: &AppHandle, client: &Arc<RoonClient>) -> Result<(), ApiError> {
    let roon = app.state::<Roon>();
    let paired = client.pairing().paired_core_id().await;
    roon.update(|inner| inner.paired_core_id = paired.clone());
    match &paired {
        Some(id) => println!("[roon] looking for the paired Core ({id})..."),
        None => {
            println!("[roon] searching the network for a Roon Core...");
            // First run: open Settings, where the Roon Core card explains
            // what to do (it glows until a Core is paired)
            crate::show(app, crate::SETTINGS_WINDOW);
        }
    }

    // Keep the handle: dropping it would stop discovery.
    let (discovery, mut found) = roon_sood::SoodDiscovery::start().await?;
    // Also ask the manual address and the Core's last known address directly,
    // so finding it doesn't rely on multicast or broadcast getting through.
    let settings_path = crate::settings::path(app);
    let settings = settings_path
        .as_deref()
        .map(crate::settings::load)
        .unwrap_or_default();
    let mut saved_host = settings.last_core_host.clone();
    let control = discovery.control();
    control.set_known_hosts(known_hosts(&settings));
    *roon.control.lock().unwrap() = Some(control);

    // Direct connection to a typed-in address (Settings > Roon Core > Manual):
    // used only if that address doesn't answer the search within a few
    // seconds, for networks that block the search's UDP port but not the
    // Core's own port. Any change to the address re-arms it.
    let (manual_tx, mut manual_rx) = tokio::sync::mpsc::unbounded_channel::<()>();
    *roon.manual_changed.lock().unwrap() = Some(manual_tx);
    const DIRECT_WAIT: Duration = Duration::from_secs(5);
    const DIRECT_RETRY: Duration = Duration::from_secs(15);
    let direct_due = tokio::time::sleep(DIRECT_WAIT);
    tokio::pin!(direct_due);
    let mut direct_task: Option<JoinHandle<()>> = None;
    // Result of the direct attempt: the Core it reached, or None if it failed
    let (direct_tx, mut direct_rx) = tokio::sync::mpsc::channel::<Option<String>>(1);
    let (connected_tx, mut connected_rx) = tokio::sync::mpsc::channel::<String>(1);
    let mut attempts: HashMap<String, JoinHandle<()>> = HashMap::new();
    let mut ignored: HashSet<String> = HashSet::new();
    // The Core connected to, once there is one
    let mut connected: Option<String> = None;
    let mut prune = tokio::time::interval(Duration::from_secs(30));

    loop {
        tokio::select! {
            Some(connected_id) = connected_rx.recv() => {
                // Cancel any attempts still waiting on other Cores.
                for (core_id, task) in attempts.drain() {
                    if core_id != connected_id {
                        task.abort();
                    }
                }
                connected = Some(connected_id);
            }

            _ = prune.tick() => roon.remove_stale_cores(),

            // The manual address was saved or cleared: start the clock again
            Some(()) = manual_rx.recv() => {
                if let Some(task) = direct_task.take() {
                    task.abort();
                }
                roon.set_direct(DirectState::Idle);
                direct_due.as_mut().reset(tokio::time::Instant::now() + DIRECT_WAIT);
            }

            // Time to try the typed address directly, if nothing else worked
            () = &mut direct_due => {
                // Re-arm; only does anything when the conditions below hold
                direct_due.as_mut().reset(tokio::time::Instant::now() + DIRECT_RETRY);
                if connected.is_some() || direct_task.as_ref().is_some_and(|t| !t.is_finished()) {
                    continue;
                }
                let settings = settings_path.as_deref().map(crate::settings::load).unwrap_or_default();
                let Some(host) = settings.manual_core_host.clone() else {
                    roon.set_direct(DirectState::Idle);
                    continue;
                };
                // The search reached it: the normal path has it covered
                if roon.status().available.iter().any(|c| c.host == host) {
                    roon.set_direct(DirectState::Idle);
                    continue;
                }
                let port = settings.manual_core_port;
                println!("[roon] {host} didn't answer the search, connecting to {host}:{port} directly...");
                roon.set_direct(DirectState::Connecting);
                let client = client.clone();
                let direct_tx = direct_tx.clone();
                direct_task = Some(tokio::spawn(async move {
                    match client.connect(&host, port).await {
                        Ok(core) => {
                            let _ = direct_tx.send(Some(core.core_id().to_string())).await;
                        }
                        Err(e) => {
                            eprintln!("[roon] direct connection to {host}:{port} failed: {e} (will keep trying)");
                            let _ = direct_tx.send(None).await;
                        }
                    }
                }));
            }

            Some(result) = direct_rx.recv() => {
                match result {
                    Some(core_id) => {
                        // A typed address means "use that Core": if it isn't
                        // the paired one, switch to it, which restarts the app
                        if paired.as_ref().is_some_and(|p| *p != core_id) {
                            println!("[roon] the Core at the manual address is a different Core, switching to it");
                            if let Some(path) = roon.state_path.get() {
                                let _ = FileStateStore::new(path.clone()).save_paired_core_id(Some(&core_id));
                            }
                            std::env::set_var(crate::RESTARTED_ENV, "1");
                            app.restart();
                        }
                        for (_, task) in attempts.drain() {
                            task.abort();
                        }
                        connected = Some(core_id);
                        roon.set_direct(DirectState::Connected);
                    }
                    None => roon.set_direct(DirectState::Failed),
                }
            }

            result = found.recv() => {
                let core = match result {
                    Ok(core) => core,
                    Err(RecvError::Lagged(_)) => continue,
                    Err(RecvError::Closed) => return Err(ApiError::ConnectionClosed),
                };
                let name = core.name.clone().unwrap_or_else(|| "Roon Core".into());
                // Where the connected Core was last seen, to notice it moving
                let last_host = roon
                    .status()
                    .connected
                    .filter(|c| c.core_id == core.core_id && !c.host.is_empty())
                    .map(|c| c.host);
                roon.core_seen(CoreInfo {
                    core_id: core.core_id.clone(),
                    name: name.clone(),
                    host: core.host.to_string(),
                    port: core.http_port,
                });

                // Remember where the Core we use lives, so it can be asked
                // directly next time (only written when the address changes)
                let ours = paired.as_ref() == Some(&core.core_id)
                    || connected.as_ref() == Some(&core.core_id);
                if ours && !core.host.is_loopback() {
                    let host = core.host.to_string();
                    if saved_host.as_ref() != Some(&host) {
                        if let Some(path) = &settings_path {
                            let mut current = crate::settings::load(path);
                            current.last_core_host = Some(host.clone());
                            if crate::settings::save(path, &current).is_ok() {
                                if let Some(control) = roon.control.lock().unwrap().as_ref() {
                                    control.set_known_hosts(known_hosts(&current));
                                }
                                saved_host = Some(host);
                            }
                        }
                    }
                }

                // Connected: just keep the reconnect address current (does
                // nothing unless the Core's address changed)
                if let Some(connected_id) = &connected {
                    if *connected_id == core.core_id {
                        let host = core.host.to_string();
                        if last_host.is_some_and(|last| last != host) {
                            println!("[roon] \"{name}\" is now at {host}, reconnecting there");
                        }
                        client.set_core_address(&host, core.http_port);
                    }
                    continue;
                }

                // Already paired with a different Core: leave this one alone.
                if paired.as_ref().is_some_and(|id| *id != core.core_id) {
                    if ignored.insert(core.core_id.clone()) {
                        println!(
                            "[roon] ignoring \"{name}\" at {} ({}), it isn't the paired Core",
                            core.host, core.core_id
                        );
                    }
                    continue;
                }

                // Discovery re-announces Cores every ~10 seconds; don't stack up attempts.
                if attempts.get(&core.core_id).is_some_and(|task| !task.is_finished()) {
                    continue;
                }
                let first_try = !attempts.contains_key(&core.core_id);
                if first_try {
                    println!("[roon] found \"{name}\" at {}, registering...", core.host);
                    if paired.is_none() {
                        println!("[roon] (if it stops here, enable \"Roon: Toasted\" in Roon > Settings > Extensions)");
                    }
                }

                let client = client.clone();
                let connected_tx = connected_tx.clone();
                let host = core.host.to_string();
                let port = core.http_port;
                let core_id = core.core_id.clone();
                let task = tokio::spawn(async move {
                    match client.connect(&host, port).await {
                        Ok(_) => {
                            let _ = connected_tx.send(core_id).await;
                        }
                        // Only report the first failure; retries happen quietly.
                        Err(e) if first_try => {
                            eprintln!("[roon] couldn't register with \"{name}\" at {host}: {e} (will keep trying)");
                        }
                        Err(_) => {}
                    }
                });
                attempts.insert(core.core_id.clone(), task);
            }
        }
    }
}
